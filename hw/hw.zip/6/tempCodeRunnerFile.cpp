#include <stdio.h>
#define MAX 1000
int main()
{
    int Adata[MAX];
    int Bdata[MAX];
    int sumdata[MAX];
    int m, n;
    scanf("%d", &m);
    scanf("%d", &n);
    getchar();
    int A[m][n];
    int B[m][n];
    int sum[m][n];
    int x, flag, na, nb, ns, i, j, k;
    char c;
    na = 0;
    nb = 0;
    while ((c = getchar()) != '\n')
    {
        flag = 1;
        x = 0;
        while ((c < '0' || c > '9') && c != '\n')
        {
            if (c == '-')
                flag = -1;
            c = getchar();
        }
        if (c == '\n')
            break;
        while (c >= '0' && c <= '9')
        {
            x = 10 * x + c - '0';
            c = getchar();
        }
        x = x * flag;
        Adata[na++] = x;
        if (c == '\n')
            break;
    }
    for (i = 0, k = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &A[i][j]);
            if (A[i][j])
                A[i][j] = Adata[k++];
        }
    }
    c = getchar();
    while ((c = getchar()) != '\n')
    {
        flag = 1;
        x = 0;
        while ((c < '0' || c > '9') && c != '\n')
        {
            if (c == '-')
                flag = -1;
            c = getchar();
        }
        if (c == '\n')
            break;
        while (c >= '0' && c <= '9')
        {
            x = 10 * x + c - '0';
            c = getchar();
        }
        x = x * flag;
        Bdata[nb++] = x;
        if (c == '\n')
            break;
    }
    for (i = 0, k = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &B[i][j]);
            if (B[i][j])
                B[i][j] = Bdata[k++];
        }
    }
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            sum[i][j] = A[i][j] + B[i][j];
            if (sum[i][j])
                sumdata[ns++] = sum[i][j];
        }
    }
    for (i = 0; i < ns - 1; i++)
        printf("%d ", sumdata[i]);
    if (ns)
        printf("%d\n", sumdata[ns - 1]);
    else
        printf("\n");
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n - 1; j++)
        {
            if (sum[i][j])
                printf("1 ");
            else
                printf("0 ");
        }
        if (sum[i][n - 1])
            printf("1\n");
        else
            printf("0\n");
    }
    return 0;
}
